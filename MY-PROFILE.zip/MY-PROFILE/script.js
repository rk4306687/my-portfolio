// Smooth Scroll for navbar links
document.querySelectorAll('nav a[href^="#"]').forEach(anchor => {
  anchor.addEventListener('click', function(e) {
    e.preventDefault();
    const targetID = this.getAttribute('href');
    document.querySelector(targetID).scrollIntoView({
      behavior: 'smooth'
    });
  });
});

// Contact form validation and submission
const form = document.querySelector('form');

form.addEventListener('submit', function(e) {
  e.preventDefault();
  
  const name = form.querySelector('input[type="text"]').value.trim();
  const email = form.querySelector('input[type="email"]').value.trim();
  const message = form.querySelector('textarea').value.trim();

  if(name === '') {
    alert('Please enter your name.');
    return;
  }

  if(email === '' || !validateEmail(email)) {
    alert('Please enter a valid email address.');
    return;
  }

  // Optional: message can be empty or not
  // if(message === '') {
  //   alert('Please enter a message.');
  //   return;
  // }

  alert('Thank you for contacting me! I will get back to you soon.');
  form.reset();
});

// Email validation helper function
function validateEmail(email) {
  const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return re.test(email.toLowerCase());
}
